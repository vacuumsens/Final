from smbus2 import SMBus
import bisect
import time
from tempConversion import Diode_VtoK

class ADS1115:
    ADDRESS = 0x48
    REG_CONVERT = 0x00
    REG_CONFIG = 0x01

    # 128 SPS, singleshot, comparator disabled, gain ±4.096V
    BASE_CONFIG = 0x8383

    def __init__(self, bus=1, address=ADDRESS):
        self.bus = SMBus(bus)
        self.address = address

    def read_raw(self):
        config = self.BASE_CONFIG
        self.bus.write_i2c_block_data(
            self.address,
            self.REG_CONFIG,
            [(config >> 8) & 0xFF, config & 0xFF]
        )

        time.sleep(0.01)

        data = self.bus.read_i2c_block_data(self.address, self.REG_CONVERT, 2)
        value = (data[0] << 8) | data[1]

        if value & 0x8000:
            value -= 65536

        return value

    def read_voltage(self):
        raw = self.read_raw()
        return raw * 4.096 / 32768.0 # must match gain

class TempSensor:
    def __init__(self, adc=None):
        self.adc = adc or ADS1115()
        self.voltages = [v for v, _ in Diode_VtoK]

    def read_voltage(self):
        return self.adc.read_voltage()

    def voltage_to_kelvin(self, voltage):
        idx = bisect.bisect_left(self.voltages[::-1], voltage)
        idx = len(self.voltages) - idx - 1

        if idx <= 0:
            return Diode_VtoK[0][1]
        if idx >= len(Diode_VtoK) - 1:
            return Diode_VtoK[-1][1]

        v1, t1 = Diode_VtoK[idx]
        v2, t2 = Diode_VtoK[idx + 1]

        return t1 + (voltage - v1) * (t2 - t1) / (v2 - v1)

    def read_temperature(self):
        v = self.read_voltage()
        return self.voltage_to_kelvin(v)
