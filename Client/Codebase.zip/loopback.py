import serial
import time

port = serial.Serial(
    port='/dev/serial0',
    baudrate=115200,
    timeout=1
)

test_msg = b'Hello loopback!\n'
port.write(test_msg)
time.sleep(0.1)

received = port.read(len(test_msg))
port.close()

if received == test_msg:
    print(f"PASS: Got back '{received.decode().strip()}'")
else:
    print(f"FAIL: Sent {test_msg!r}, received {received!r}")


