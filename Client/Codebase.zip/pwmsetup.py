from gpiozero import PWMOutputDevice

HEATER_PIN = 18
PWM_FREQ = 50

class HeaterController:
    def __init__(self, pin=HEATER_PIN, frequency=PWM_FREQ):
        self.pin = pin
        self.frequency = frequency
        self._current_power = 0
        
        self.pwm = PWMOutputDevice(pin, frequency=frequency, initial_value=0)
        print(f"[Heater] initialization complete: Pin={self.pin}, Freq={self.frequency}Hz")

    def set_power(self, duty_cycle):
        """
        set power(0 - 100)
        duty_cycle: float/int 0-100
        """
        if duty_cycle < 0: duty_cycle = 0
        if duty_cycle > 100: duty_cycle = 100
        
        #gpiozero uses 0-1 range
        self.pwm.value = duty_cycle / 100.0
        self._current_power = duty_cycle
        print(f"[Heater] Power set to: {duty_cycle}%")

    def stop(self):
        #turn off the heater
        self.set_power(0)
        print("[Heater] has stopped.")

    def cleanup(self):
        self.pwm.close()
        print("[Heater] GPIO has released its resource.")
