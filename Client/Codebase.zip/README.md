## To setup SSH git access on each clientpi
### Create SSH Keys on client
`ssh-keygen -t ed25519 -C "vsens@<color>.local"`
### add the given key into the repo
`Settings > Deploy Keys > Add deploy key`
