import serial
import time


#DEFAULT_SERIAL_PORT = "/dev/ttyUSB0"
DEFAULT_SERIAL_PORT = "/dev/serial0"
DEFAULT_BAUD_RATE = 9600
SENSOR_ADDR = "253"           
CMD_PRESSURE = "PR3"          
CMD_TERMINATOR = ";FF"        
RESP_ACK = "ACK"             

class MKS901PSensor:
    def __init__(self, port=DEFAULT_SERIAL_PORT, baudrate=DEFAULT_BAUD_RATE):
        self.port = port
        self.baudrate = baudrate
        self.serial_conn = None
        self.packet_count = 0
        if not self.connect():
            print("Failed to connect to MKS 901P sensor. Will use random values.")
        
    def connect(self):
        try:
            self.serial_conn = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=serial.EIGHTBITS,      
                parity=serial.PARITY_NONE,       
                stopbits=serial.STOPBITS_ONE,    
                xonxoff=False,                   
                rtscts=False,                    
                timeout=0.5                  
            )
            #Flush any old data
            self.serial_conn.reset_input_buffer()
            self.serial_conn.reset_output_buffer()
            print(f"Serial port: {self.port}")
            print(f"Baud rate: {self.baudrate}")
            print(f"Protocol: @{SENSOR_ADDR}...;FF")
            return True
        except serial.SerialException as e:
            print(f"Error opening serial port {self.port}: {e}")
            return False
    
    def disconnect(self):
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
            print("Serial port closed.")
    
    def send_query(self, cmd):
        if not self.serial_conn or not self.serial_conn.is_open:
            return False
        #Format:@253PR3?;FF
        packet = f"@{SENSOR_ADDR}{cmd}?{CMD_TERMINATOR}"
        #Flush input buffer before sending to avoid reading old data
        self.serial_conn.reset_input_buffer()
        try:
            self.serial_conn.write(packet.encode('ascii'))
            return True
        except serial.SerialException as e:
            print(f"Failed to write command: {e}")
            return False
    
    def read_response(self):
        #Read and parse response:@253ACK1.23E-4;FF
        if not self.serial_conn or not self.serial_conn.is_open:
            return None
        time.sleep(0.2)  #200ms delay
        try:
            response = self.serial_conn.read(256).decode('ascii', errors='ignore')
            if not response:
                return None
            #Look for ACK
            ack_pos = response.find(RESP_ACK)
            if ack_pos != -1:
                #Move pointer past "ACK" to start of number
                value_str = response[ack_pos + len(RESP_ACK):]
                #Parse the value to handle scientific notation e.g. 1.23E-4
                #Find the end of the number (before ;FF or end of string)
                end_pos = value_str.find(';')
                if end_pos != -1:
                    value_str = value_str[:end_pos]  #Get pure number
                try:
                    return float(value_str.strip())
                except ValueError:
                    return None
            #Check for NAK(Error)
            if "NAK" in response:
                print(f"Sensor returned NAK (Error): {response}")
            return None
        except serial.SerialException as e:
            print(f"Error reading response: {e}")
            return None
    
    def read_pressure(self):
        #Poll the sensor for pressure reading
        if self.send_query(CMD_PRESSURE):
            pressure = self.read_response()
            if pressure is not None:
                self.packet_count += 1
                print(f"[#{self.packet_count}] Pressure: {pressure:.4e} Torr")
                return pressure
            else:
                print("No response from sensor.")
        return 0.0

def init_vac_sensor(port=DEFAULT_SERIAL_PORT, baudrate=DEFAULT_BAUD_RATE):
    #Initialize MKS 901P vacuum sensor
    vac_sensor = MKS901PSensor(port=port, baudrate=baudrate)
    if not vac_sensor.connect():
        print("Failed to connect to MKS 901P sensor. Will use random values.")
        vac_sensor = None
    return vac_sensor is not None

