import serial
import time

PORT = "/dev/serial0"
BAUD = 9600

def debug_sensor():
    try:
        ser = serial.Serial(PORT, BAUD, timeout=2)
        print("--- Sensor Communication Test ---")
        
        # 1. Try querying pressure using address 253
        # 2. Also try 254 (general broadcast address) in case the address is misconfigured
        for addr in ["253", "254"]:
            cmd = f"@{addr}PR3?;FF\r"
            print(f"Sending command to address {addr}: {cmd.strip()}")
            
            ser.reset_input_buffer()
            ser.write(cmd.encode('ascii'))
            
            time.sleep(0.5)  # Give the industrial sensor some time to respond
            
            if ser.in_waiting > 0:
                resp = ser.read(ser.in_waiting).decode('ascii', errors='ignore')
                print(f">>> Received sensor response: {resp.strip()}")
                return  # Exit if successful
            else:
                print(f"No response from address {addr}.")
        
        print("\n[Result] Still no valid response received.")
        ser.close()
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    debug_sensor()
