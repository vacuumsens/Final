import requests
import time
import argparse
import random
import os
import socket
from enum import Enum, auto
from smbus2 import SMBus
from gpiozero import DigitalOutputDevice
from getmac import get_mac_address as gma

try:
    from I2C import TempSensor
    from pwmsetup import HeaterController
    from pidcontroller import PIDController
    TEMP_HW_AVAILABLE = True
except ImportError:
    TEMP_HW_AVAILABLE = False
    print("I2C/PWM hardware modules not found. Simulating temp data.")

try:
    from vac import MKS901PSensor
except ImportError:
    MKS901PSensor = None
    print("Serial Vacuum hardware not found. Simulating vac data.")


# === CONFIGURATION ===
SERVER_URL = "http://blue.local"
SERVER_PORT = 3000
SEND_INTERVAL = 5  
BASE_INTERVAL = 5
CLIENT_ID = None
CURRENT_SETPOINT = 300.0 
CURRENT_TEMP_CONTROL = False
CURRENT_LOW_POWER = False
DONE_GPIO_PIN = 23
DONE_PULSE_SECONDS = 0.1
LOW_POWER_GRACE_SECONDS = 10

# MAX17048 fuel gauge (I2C)
MAX17048_I2C_BUS = 1
MAX17048_ADDR = 0x36
MAX17048_REG_VCELL = 0x02
MAX17048_REG_SOC = 0x04
BQ_I2C_BUS = 1
BQ_ADDR = 0x08  # The '03' suffix on your chip usually dictates address 0x08
NUM_CELLS = 3 
temp_sensor = None
vac_sensor = None
heater = None
pid = None

if TEMP_HW_AVAILABLE:
    try:
        temp_sensor = TempSensor()
        heater = HeaterController()
        pid = PIDController(
            temp_sensor=temp_sensor,
            heater=heater,
            setpoint=CURRENT_SETPOINT,
            dt=1.0
        )
        pid.enabled = CURRENT_TEMP_CONTROL
        pid.start()
        print("PID controller threaded successfully.")
    except Exception as e:
        print(f"Error initializing Temp/PID hardware: {e}")
        temp_sensor = None
        pid = None

if MKS901PSensor is not None:
    try:
        vac_sensor = MKS901PSensor()
    except Exception as e:
        print(f"Error initializing Vacuum sensor: {e}")
        vac_sensor = None

def read_sensor_value():
    global CLIENT_ID
    sensor_data = {
        "sensorId": CLIENT_ID if CLIENT_ID else gma(),
        "vac": read_vac(),
        "temp": read_temp(),
        "battery_voltage": get_battery_voltage(),
        "batt": get_battery_percent(),
        "setpoint": CURRENT_SETPOINT,
        "tempControl": CURRENT_TEMP_CONTROL,
        "lowPower": CURRENT_LOW_POWER
    }
    return sensor_data

def get_bq_calibration(bus):
    adc_gain1 = bus.read_byte_data(BQ_ADDR, 0x50)
    adc_gain2 = bus.read_byte_data(BQ_ADDR, 0x59)
    gain_bits = ((adc_gain1 & 0x0C) << 1) | ((adc_gain2 & 0xE0) >> 5)
    gain_uv = 365 + gain_bits 
    offset_raw = bus.read_byte_data(BQ_ADDR, 0x51)
    if offset_raw > 127:
        offset_raw -= 256
    offset_mv = offset_raw
    
    return gain_uv, offset_mv

def get_battery_voltage():
    try:
        with SMBus(BQ_I2C_BUS) as bus:
            sys_ctrl1 = bus.read_byte_data(BQ_ADDR, 0x04)
            if not (sys_ctrl1 & 0x10):
                bus.write_byte_data(BQ_ADDR, 0x04, sys_ctrl1 | 0x10)
                time.sleep(0.05)
            gain_uv, offset_mv = get_bq_calibration(bus)
            vbat_h = bus.read_byte_data(BQ_ADDR, 0x2A)
            vbat_l = bus.read_byte_data(BQ_ADDR, 0x2B)
            adc_vbat = (vbat_h << 8) | vbat_l
            pack_mv = (4 * gain_uv * adc_vbat) / 1000.0 + (NUM_CELLS * offset_mv)
            return round(pack_mv / 1000.0, 3)
            
    except Exception as e:
        print(f"BQ76920 Read Error: {e}")
        return None

def get_battery_percent():
    voltage = get_battery_voltage()
    if voltage is None:
        return None
    if voltage >= 12.6:
        percent = 100.0
    elif voltage <= 9.0:
        percent = 0.0
    else:
        percent = ((voltage - 9.0) / (12.6 - 9.0)) * 100.0
        
    return round(percent, 2)

def read_temp():
    global temp_sensor
    if temp_sensor is None:
        return round(random.uniform(290.0, 310.0), 2)
    try:
        return round(temp_sensor.read_temperature(), 2)
    except Exception:
        return round(random.uniform(290.0, 310.0), 2)

def read_vac():
    global vac_sensor
    if vac_sensor is None:
        return round(random.uniform(1.0, 100.0), 2)
    try:
        return round(vac_sensor.read_pressure(), 2)
    except Exception:
        return round(random.uniform(1.0, 100.0), 2)

def auto_discover_server():
    print("Searching network for Vsens server...")
    UDP_IP = "255.255.255.255"
    UDP_PORT = 8888
    MESSAGE = b"VSENS_DISCOVER"

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(2.0)

    while True:
        try:
            sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
            data, addr = sock.recvfrom(1024)
            response = data.decode('utf-8')
            if response.startswith("VSENS_SERVER:"):
                port = response.split(":")[1]
                found_url = f"http://{addr[0]}:{port}"
                print(f"Found server at {found_url}")
                return found_url
        except socket.timeout:
            print("No server found, retrying...")
            time.sleep(2)

def print_controller(current_temp):
    global CURRENT_SETPOINT
    global CURRENT_TEMP_CONTROL
    global pid
    
    error = CURRENT_SETPOINT - current_temp
    
    if pid is not None:
        status = pid.get_status()
        state_str = "ACTIVE" if CURRENT_TEMP_CONTROL else "DISABLED"
        print(
            f"PID {state_str}: "
            f"T={current_temp:.2f}K | "
            f"SP={CURRENT_SETPOINT:.2f}K | "
            f"Error={error:.2f}K | "
            f"Duty={status.get('duty', 0.0):.1f}%"
        )
    else:
        print(
            f"Simulated: "
            f"T={current_temp:.2f}K | "
            f"SP={CURRENT_SETPOINT:.2f}K | "
            f"Error={error:.2f}K | "
            f"(Hardware Offline)"
        )

def send():
    global SEND_INTERVAL
    global SERVER_URL
    global BASE_INTERVAL
    global CURRENT_SETPOINT
    global CURRENT_TEMP_CONTROL
    global CURRENT_LOW_POWER
    global pid
    
    data = read_sensor_value()
    current_temp = data["temp"]
    
    print(f"POST request to {SERVER_URL}/api/client")
    print(f"   Payload: Vac={data.get('vac')} Torr | Temp={data.get('temp')}K | Batt={data.get('batt')}% | Voltage={data.get('battery_voltage')}")

    response_payload = None
    try:
        response = requests.post(f"{SERVER_URL}/api/client", json=data)
        try:
            server_data = response.json()
            response_payload = server_data

            if "setpoint" in server_data:
                new_sp = float(server_data["setpoint"])
                if new_sp != CURRENT_SETPOINT:
                    CURRENT_SETPOINT = new_sp
                    print(f"-> SETPOINT updated to: {CURRENT_SETPOINT}K")
                    if pid is not None:
                        pid.set_setpoint(CURRENT_SETPOINT)
            if "tempControl" in server_data:
                new_tc = bool(server_data["tempControl"])
                if new_tc != CURRENT_TEMP_CONTROL:
                    CURRENT_TEMP_CONTROL = new_tc
                    print(f"-> TEMP CONTROL state changed to: {CURRENT_TEMP_CONTROL}")
                    if pid is not None:
                        pid.enabled = CURRENT_TEMP_CONTROL
            if "lowPower" in server_data:
                new_lp = bool(server_data["lowPower"])
                if new_lp != CURRENT_LOW_POWER:
                    CURRENT_LOW_POWER = new_lp
                    print(f"-> LOW POWER state changed to: {CURRENT_LOW_POWER}")
                        
        except ValueError:
            pass 

        SEND_INTERVAL = BASE_INTERVAL 
    except Exception as e:
        SEND_INTERVAL = SEND_INTERVAL * 1.5
        print(f"Error sending data: {e}")

    print_controller(current_temp)
    print("-" * 40)
    time.sleep(SEND_INTERVAL)
    return response_payload


# === LOW POWER FSM ===
class SleepState(Enum):
    BOOT = auto()
    READ = auto()
    SEND = auto()
    SHUTDOWN = auto()
    DONE = auto()
    TERMINATED = auto() 


class SleepCycleFSM:
    def __init__(self, done_gpio=DONE_GPIO_PIN, pulse_s=DONE_PULSE_SECONDS):
        self.state = SleepState.BOOT
        self.context = {}                 
        self.pulse_s = pulse_s
        self._done_pin = DigitalOutputDevice(done_gpio, initial_value=False)

    def run(self):
        self._run_states([
            (SleepState.BOOT,     self._do_boot),
            (SleepState.READ,     self._do_read),
            (SleepState.SEND,     self._do_send),
            (SleepState.SHUTDOWN, self._do_shutdown),
            (SleepState.DONE,     self._do_done),
        ])
        self._enter(SleepState.TERMINATED)

    def power_off(self):
        self._run_states([
            (SleepState.SHUTDOWN, self._do_shutdown),
            (SleepState.DONE,     self._do_done),
        ])
        self._enter(SleepState.TERMINATED)

    def _run_states(self, sequence):
        for state, handler in sequence:
            self._enter(state)
            self._safe_call(state, handler)

    def _enter(self, state):
        print(f"[FSM] -> {state.name}")
        self.state = state

    def _safe_call(self, state, fn):
        try:
            fn()
        except Exception as e:
            print(f"[FSM] {state.name} error: {e}")

    def _do_boot(self):
        self.context["started_at"] = time.time()
        self.context["mac"] = gma()

    def _do_read(self):
        self.context["data"] = read_sensor_value()
        print(f"[FSM] Sensor data: {self.context['data']}")

    def _do_send(self):
        data = self.context.get("data")
        if not data:
            return
        response = requests.post(f"{SERVER_URL}/api/client", json=data, timeout=10)
        self.context["response_status"] = response.status_code
        print(f"[FSM] Server response: {response.status_code} - {response.text}")

    def _do_shutdown(self):
        try:
            os.sync()
        except Exception:
            pass
        if vac_sensor is not None:
            try:
                vac_sensor.disconnect()
            except Exception:
                pass
        if pid is not None:
            try:
                pid.stop()
            except Exception:
                pass

    def _do_done(self):
        self._done_pin.on()
        time.sleep(self.pulse_s)
        self._done_pin.off()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="POST Sensor Data Sender")
    parser.add_argument('--ip', type=str, default="", help='IP Address of Server')
    parser.add_argument('--interval', type=float, default=SEND_INTERVAL, help='Interval between sends in seconds')
    parser.add_argument('--hostname', type=str, default="", help='Hostname of Server')
    parser.add_argument('--port', type=int, default=SERVER_PORT, help='Port of Server')
    parser.add_argument('--id', type=str, default="", help='Override Sensor ID for simulation')
    parser.add_argument('--sleep-mosfet', action='store_true', help='Enable low-power one-shot cycle via the TPL5110 + Q8 sleep circuit.')
    
    args = parser.parse_args()
    
    if args.id.strip() != "":
        CLIENT_ID = args.id.strip()

    ip_arg = args.ip.strip()
    host_arg = args.hostname.strip()
    port_arg = args.port

    if ip_arg != "":
        SERVER_URL = f'http://{ip_arg}:{port_arg}'
    elif host_arg != "":
        SERVER_URL = f'http://{host_arg}:{port_arg}'
    else:
        SERVER_URL = auto_discover_server()
        
    SEND_INTERVAL = args.interval
    BASE_INTERVAL = args.interval

    if args.sleep_mosfet:
        fsm = SleepCycleFSM()
        try:
            fsm.run()
        except KeyboardInterrupt:
            print("Quitting.")
            if vac_sensor is not None:
                vac_sensor.disconnect()
            if pid is not None:
                pid.stop()
        exit(0)

    fsm = None
    prev_low_power = None
    try:
        while True:
            payload = send()
            low_power = bool(payload and payload.get("lowPower"))
            if low_power:
                if prev_low_power is False:
                    print(f"[client] Low-power mode enabled - shutting down in {LOW_POWER_GRACE_SECONDS}s...")
                    time.sleep(LOW_POWER_GRACE_SECONDS)
                print("[client] Powering off via TPL5110.")
                if fsm is None:
                    fsm = SleepCycleFSM()
                fsm.power_off()
                break
            prev_low_power = low_power
    except KeyboardInterrupt:
        print("\nQuitting.")
        if vac_sensor is not None:
            vac_sensor.disconnect()
        if pid is not None:
            pid.stop()
        exit(0)
