import time
import threading

class PIDController(threading.Thread):
    def __init__(self, temp_sensor, heater, setpoint=300.0, dt=1.0):
        super().__init__()
        self.temp_sensor = temp_sensor
        self.heater = heater
        self.setpoint = setpoint
        self.dt = dt
        self.enabled = False
        self.running = True 
        
        self.duty = 0.0
        self.current_temp = None 
        self.Kp = 5.0 
        self.Ki = 0.1
        self.Kd = 0.0
        self.daemon = True

    def set_setpoint(self, sp):
        self.setpoint = sp

    def get_status(self):
        return {"duty": self.duty, "enabled": self.enabled}

    def stop(self):
        self.running = False
        if self.heater:
            self.heater.stop()
            self.heater.cleanup()

    def run(self):
        integral = 0.0
        prev_error = 0.0
        
        print(f"[PID] Thread started. Waiting for Temp Control activation...")
        
        while self.running:
            if not self.enabled:
                if self.duty > 0:
                    self.duty = 0.0
                    if self.heater:
                        self.heater.set_power(0)
                integral = 0.0
                time.sleep(self.dt)
                continue
                
            try:
                self.current_temp = self.temp_sensor.read_temperature() 
            except Exception:
                self.current_temp = None
                
            if self.current_temp is None:
                time.sleep(self.dt)
                continue
                
            error = self.setpoint - self.current_temp
            
            integral += error * self.dt
            integral = max(0.0, min(100.0, integral))
            
            derivative = (error - prev_error) / self.dt
            
            output = (self.Kp * error) + (self.Ki * integral) + (self.Kd * derivative)
            
            if error < 0:
                self.duty = 0.0
            else:
                self.duty = max(0.0, min(100.0, output))
            
            if self.heater:
                self.heater.set_power(self.duty)
                
            prev_error = error
            time.sleep(self.dt)
