import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn
import tempConversion as tc


class ADC:
    def __init__(
        self,
        address=0x48,
        gain=2,
        data_rate=128,
        i2c_bus=None,
    ):
        """
        Initialize ADS1115.

        :param address: I2C address (default 0x48)
        :param gain: PGA gain (default 2 → ±2.048 V)
        :param data_rate: Samples per second (default 128)
        :param i2c_bus: Optional shared I2C bus
        """
        # Create I2C bus if not provided
        if i2c_bus is None:
            self.i2c = busio.I2C(board.SCL, board.SDA)
        else:
            self.i2c = i2c_bus

        # Create ADC
        self.ads = ADS.ADS1115(self.i2c, address=address)

        # Configuration
        self.ads.gain = gain
        self.ads.data_rate = data_rate

        # Differential channel A0 - A1
        self.channel = AnalogIn(self.ads, ADS.P0, ADS.P1)

    def read_voltage(self):
        """
        Read differential voltage (A0 - A1) in volts.
        """
        return self.channel.voltage

class tempSensor(ADC):
    def __init__(self, address=0x48, gain=2, data_rate=128, i2c_bus=None):
        """
        Initialize temperature sensor (inherits from ADC).
        """
        super().__init__(address, gain, data_rate, i2c_bus)

    def read_temperature(self):
        voltage = self.read_voltage()
        table = tc.Diode_VtoK
        if voltage is None:
            raise RuntimeError("Failed to read voltage from ADC.")
        
        if (voltage >= table[0][0]):
            return table[0][1]
        elif (voltage <= table[-1][0]):
            return table[-1][1]
        else:
            for i in range(1, len(table)):
                if (voltage >= table[i][0]):
                    # Linear interpolation
                    v1, k1 = table[i - 1]
                    v2, k2 = table[i]
                    temp = k1 + (k2 - k1) * (voltage - v1) / (v2 - v1)
                    return temp
        raise RuntimeError("Voltage out of range for temperature conversion.")

 